/*
 * MIT License

* Copyright (c) 2018.  Amazon Web Services, Inc. All Rights Reserved.

* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:

* The above copyright notice and this permission notice shall be included in all
* copies or substantial portions of the Software.

* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
* */

const gremlin = require('gremlin');
const __ = gremlin.process.statics

exports.handler = async event => {
  const {
      name, id, label, year, partition_key, endpoint
    } = event.queryStringParameters || {};
  const {DriverRemoteConnection} = gremlin.driver;
  const {Graph} = gremlin.structure;
  // Use wss:// for secure connections. See https://docs.aws.amazon.com/neptune/latest/userguide/access-graph-ssl.html
  
  if (endpoint) {
    if (endpoint == 1) {
      var dc = new DriverRemoteConnection(
        `wss://${process.env.NEPTUNE_CLUSTER_ENDPOINT_1}:${process.env.NEPTUNE_PORT}/gremlin`,
        {mimeType: 'application/vnd.gremlin-v2.0+json'}
      );
    } else if (endpoint == 2) {
      var dc = new DriverRemoteConnection(
        `wss://${process.env.NEPTUNE_CLUSTER_ENDPOINT_2}:${process.env.NEPTUNE_PORT}/gremlin`,
        {mimeType: 'application/vnd.gremlin-v2.0+json'}
      );
    } else if (endpoint == 3) {
      var dc = new DriverRemoteConnection(
        `wss://${process.env.NEPTUNE_CLUSTER_ENDPOINT_3}:${process.env.NEPTUNE_PORT}/gremlin`,
        {mimeType: 'application/vnd.gremlin-v2.0+json'}
      );
    }
  } else {
      var dc = new DriverRemoteConnection(
        `wss://${process.env.NEPTUNE_CLUSTER_ENDPOINT}:${process.env.NEPTUNE_PORT}/gremlin`,
        {mimeType: 'application/vnd.gremlin-v2.0+json'}
      );
  }
  const graph = new Graph();
  const g = graph.traversal().withRemote(dc);
  const withTokens = '~tinkerpop.valueMap.tokens';
  
  try {
    let data = [];
    
    
    let P_V =  g.V().has('partition_key', partition_key)
    

    if (event.pathParameters.proxy.match(/initialize/ig)) {
      const nodes = await P_V
        .hasLabel('location')
        .valueMap()
        .with_(withTokens)
        .toList();
      data = nodes.map(row => ({name: row.name.toString(), id: row.id.toString()}));
    } else if (event.pathParameters.proxy.match(/search/ig)) {
      data = await P_V
        .has('location', 'name', name)
        .valueMap()
        .with_(withTokens)
        .toList();
    } else if (event.pathParameters.proxy.match(/successors/ig)) {
      data = await g.V().has('partition_key', 'AddressSum').has('location','id', id)
        .outE()
        .limit(50)
        .project('from','edge','to')
        .by(__.outV().valueMap())
        .by(__.valueMap())
        .by(__.inV().valueMap())
        .toList();
    } else if (event.pathParameters.proxy.match(/predecessors/ig)) {
      data = await g.V().has('partition_key', 'AddressSum').has('location','id', id)
        .inE()
        .limit(50)
        .project('from','edge','to')
        .by(__.outV().valueMap())
        .by(__.valueMap())
        .by(__.inV().valueMap())
        .toList();
    } else if (event.pathParameters.proxy.match(/getWeightedDegrees/ig)) {
      
      data = await P_V
                .hasLabel(label)
               .project('date','both','in_both','out_both')
                 .by('name')
                 .by(__.bothE(name).values('weight').sum())
                 .by(__.union(__.inE(name),__.bothE(name)).values('weight').sum())
                 .by(__.union(__.outE(name),__.bothE(name)).values('weight').sum())
         .toList();

    } else if (event.pathParameters.proxy.match(/getDateSummary/ig)) {

      // Get counts by date, optionally for a single year      
      var V;
      if (year) {
         V = P_V.has('year', 'name', year).inE('is_year').outV().hasLabel('record_date')
      } else {
         V = P_V.hasLabel('record_date')
      }
      
      data = await V
               .project('date','both')
                 .by('name')
                 .by(__.inE('has_date').values('weight').sum())
         .toList();

    } else if (event.pathParameters.proxy.match(/proprietorsForDate/ig)) {

      // Extract all record details for a single day
      data = await P_V
                .has('record_date','name', name)
                .as('date').inE().outV().as('reference')
                .project('date','reference','proprietor', 'subject', 'class', 'location')
                  .by(__.select('date').values('name'))
                  .by(__.select('reference').values('name'))
                  .by(__.coalesce(__.select('reference').outE('has_proprietor').inV().values('name'), __.constant('unknown')))
                  .by(__.coalesce(__.select('reference').outE('has_subject').inV().values('name'), __.constant('unknown')))
                  .by(__.coalesce(__.select('reference').outE('has_class').inV().values('name'), __.constant('unknown')))
                  .by(__.coalesce(__.select('reference').outE('has_location').inV().values('name'), __.constant('unknown')))
                .toList()

    } else if (event.pathParameters.proxy.match(/proprietorsDateSummary/ig)) {

      // Summarise records by all attributes for a single day
      // Coalesce functions handle missing data
      data = await P_V
                .has('record_date','name', name)
                .as('date').inE().outV().as('reference')
                .project('date','proprietor', 'subject', 'class', 'location')
                  .by(__.select('date').values('name'))
                  .by(__.coalesce(__.select('reference').outE('has_proprietor').inV().values('name'), __.constant('unknown')))
                  .by(__.coalesce(__.select('reference').outE('has_subject').inV().values('name'), __.constant('unknown')))
                  .by(__.coalesce(__.select('reference').outE('has_class').inV().values('name'), __.constant('unknown')))
                  .by(__.coalesce(__.select('reference').outE('has_location').inV().values('name'), __.constant('unknown')))
                .groupCount()
                .toList()

    } else if (event.pathParameters.proxy.match(/summarisingPropDates/ig)) {
      
      // Summary by date of all records for a single proprietor
      // Needs an optional year filter step added
      data = await g.V().has('partition_key', 'Main')
                .has('proprietor','name', name)
                .as('proprietor').inE('has_proprietor').outV().as('reference')
                .outE('has_date')
                .inV().as('date').values('name')
                .groupCount()
                .toList()

    }  else if (event.pathParameters.proxy.match(/SummarisingLocations/ig)) {
      
      // Summarises records by location and class with optional year filter
      var V;
      if (year) {
         V = P_V.has('year', 'name', year).inE('is_year').outV().inE('has_date').outV()
      } else {
         V = P_V.hasLabel('record')
      }
      
      data = await V.as('record')
                .outE('has_location').inV().as('location')
                .project("loc","cls")
                    .by(__.select('location').values('name'))
                    .by(__.select('record').outE('has_class').inV().values('name'))
                .groupCount()
                .toList()
    }

    dc.close();
    return formatResponse(data);
  } catch (error) {
    console.log('ERROR', error);
    dc.close();
  }
};

const formatResponse = payload => {
  return {
    statusCode: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'OPTIONS, POST, GET',
      'Access-Control-Max-Age': 2592000, // 30 days
      'Access-Control-Allow-Headers': '*',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(payload)
  };
};
